#ifndef __TIMER_H
#define __TIMER_H

#include "stm32f10x.h"
#include "key.h"
#include "transmit.h"
#include "task.h"

void TIM2_Init(void);
void TIM3_Init(void);
void TIM4_Init(void);
void TIM5_Init(void);


#endif


