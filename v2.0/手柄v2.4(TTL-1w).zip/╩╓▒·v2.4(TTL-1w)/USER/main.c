#include "init.h"

int	main()
{
	World_Init();
	
	while(1)
	{
	}
}

