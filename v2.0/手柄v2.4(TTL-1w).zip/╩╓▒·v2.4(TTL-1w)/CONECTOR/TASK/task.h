#ifndef __TASK_H
#define __TASK_H

#include "gui.h"
#include "key.h"
#include "transmit.h"

void Task_30ms(void);
void Task_500ms(void);

#endif
